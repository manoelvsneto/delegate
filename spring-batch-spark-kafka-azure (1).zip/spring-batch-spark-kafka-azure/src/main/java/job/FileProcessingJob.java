package job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import service.SparkFileProcessor;

@Configuration
public class FileProcessingJob {

    @Bean
    public Job fileProcessingJob(JobBuilderFactory jobBuilderFactory,
                                 StepBuilderFactory stepBuilderFactory,
                                 SparkFileProcessor processor) {

        Step step = stepBuilderFactory.get("sparkStep")
                .tasklet((contribution, chunkContext) -> {
                    String fileName = chunkContext.getStepContext()
                            .getJobParameters()
                            .get("fileName").toString();
                    processor.processFile(fileName);
                    return RepeatStatus.FINISHED;
                }).build();

        return jobBuilderFactory.get("fileJob")
                .start(step)
                .build();
    }
}
