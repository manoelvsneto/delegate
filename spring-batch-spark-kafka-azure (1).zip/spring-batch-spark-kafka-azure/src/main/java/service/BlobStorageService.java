package service;

import com.azure.storage.blob.*;
import org.springframework.stereotype.Component;

@Component
public class BlobStorageService {

    private final String container = "your-container-name";
    private final BlobServiceClient blobServiceClient;

    public BlobStorageService() {
        this.blobServiceClient = new BlobServiceClientBuilder()
                .connectionString("YOUR_CONNECTION_STRING")
                .buildClient();
    }

    public String getBlobUri(String fileName) {
        return blobServiceClient.getBlobContainerClient(container)
                .getBlobClient(fileName)
                .getBlobUrl();
    }

    public String getOutputBlobUri(String originalName) {
        String newName = originalName.replace(".txt", "_processed.txt");
        return blobServiceClient.getBlobContainerClient(container)
                .getBlobClient(newName)
                .getBlobUrl();
    }
}
