package service;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.SaveMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class SparkFileProcessor {

    @Autowired
    private SparkSession sparkSession;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    private BlobStorageService blobService;

    public void processFile(String fileName) {
        String inputPath = blobService.getBlobUri(fileName);
        String outputPath = blobService.getOutputBlobUri(fileName);

        Dataset<String> lines = sparkSession.read().textFile(inputPath);

        Dataset<String> processed = lines.map((MapFunction<String, String>) line -> {
            String processedLine = transformLine(line);
            kafkaTemplate.send("processed-line-events", processedLine);
            return processedLine;
        }, Encoders.STRING());

        processed.write().mode(SaveMode.Overwrite).text(outputPath);
    }

    private String transformLine(String line) {
        return "Processed: " + line;
    }
}
